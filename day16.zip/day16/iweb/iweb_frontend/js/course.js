/*1.点击“查看详情”后，跳转到课程详情页，并提供当前商品的编号*/
//ES6提供的遍历数组中每个元素的新方法：forEach
document.querySelectorAll('[data-jump-to-detail]').forEach(function(e, i){
	e.onclick = function(){
		//准备待跳转的目标地址
		let cid = e.dataset.jumpToDetail //查找当前被点击的按钮上保存的“课程编号”
		let url = 'course-detail.html?courseId='+cid
		//跳转到课程详情页
		window.open(url)
		//window.open('course-detail.html', '_self')  //在当前页打开新页面
		//window.open('course-detail.html', '_blank') //在空白页打开新页面
		//window.open('course-detail.html') //在空白页打开新页面		
	}
})

